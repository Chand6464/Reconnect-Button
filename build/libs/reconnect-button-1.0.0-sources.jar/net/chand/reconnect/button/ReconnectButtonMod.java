package net.chand.reconnect.button;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_642;

public class ReconnectButtonMod implements ClientModInitializer {
    public static class_642 lastServer;

    @Override
    public void onInitializeClient() {
        // Initialization code
    }
}
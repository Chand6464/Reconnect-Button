package net.chand.reconnect.button.mixin;

import net.chand.reconnect.button.ReconnectButtonMod;
import net.minecraft.class_2561;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_639;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin extends class_437 {

    protected DisconnectedScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    protected void init(CallbackInfo ci) {
        if (ReconnectButtonMod.lastServer != null && this.field_22787 != null) {
            
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Reconnect"), button -> {
                // We use the static method from ConnectScreen
                // Ensure the address is correctly parsed from the stored lastServer
                class_639 address = class_639.method_2950(ReconnectButtonMod.lastServer.field_3761);
                
                class_412.method_36877(
                    this, 
                    this.field_22787, 
                    address, 
                    ReconnectButtonMod.lastServer, 
                    false, 
                    null
                );
            })
            .method_46434(this.field_22789 / 2 - 100, this.field_22790 / 4 + 120 + 24, 200, 20)
            .method_46431());
        }
    }
}
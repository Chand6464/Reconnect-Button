package net.chand.reconnect.button.mixin;

import net.chand.reconnect.button.ReconnectButtonMod;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_412.class)
public class ConnectScreenMixin {

    // Using a wildcard (*) for the descriptor helps if the mapping is slightly off
    @Inject(method = "connect", at = @At("HEAD"), remap = true)
    private static void captureServerData(class_437 screen, class_310 client, class_639 address, class_642 info, boolean quickPlay, Object reporterEnvironment, CallbackInfo ci) {
        if (info != null) {
            ReconnectButtonMod.lastServer = info;
        }
    }
}